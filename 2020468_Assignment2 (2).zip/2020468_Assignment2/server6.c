
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/epoll.h>


// PORT number
#define PORT 8080
FILE * fp;

void func(int connfd)
{
	
	int n;
	// infinite loop for chat
    long unsigned int fact=1;
	int time=0;
	for (int i=0;i<20;i++) {

        int value;
        int recv;
		read(connfd,&value,sizeof(value));

		printf("From client, received Request number %d\n", value);
        fact=fact*value;

		fprintf( fp, "%lu\n ", fact);
		
		write(connfd, &fact, sizeof(unsigned long int));

		printf("Succesfully stored the results into the file !\n");
		
	
	}
}


int main()
{

	fp= fopen("file2.txt", "w");
	// Server socket id
	int sockfd, ret;

	
	struct sockaddr_in serverAddr;

	int clientSocket;


	struct sockaddr_in cliAddr;

	socklen_t addr_size;

	
	pid_t childpid;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if (sockfd < 0) {
		printf("Error in connection.\n");
		exit(1);
	}

	printf("Server Socket is created.\n");

	memset(&serverAddr, '\0',
		sizeof(serverAddr));

	
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddr.sin_port = htons(PORT);


	ret = bind(sockfd,
			(struct sockaddr*)&serverAddr,
			sizeof(serverAddr));

	if (ret < 0) {
		printf("Error in binding.\n");
		exit(1);
	}

	// Listening for connections (upto 10)
	if (listen(sockfd, 10) == 0) {
		printf("Listening...\n\n");
	}


    nfds_t nfds=0;
    struct epoll_event *fds;
    int timeout=30*1000;
    int max=0,num=0;
    int fd=0;
 
    if((fds=malloc(10*sizeof(fds)))==NULL)
    {
        printf("Error\n");
        exit(1);
    }

    max=10;

    fds->fd=sockfd;
    fds->events=EPOLLIN;
    fds->revents=0;
    num=1;


	while (1) 
    {

    nfds=num;

    int rc;
      
     rc = epoll_wait(fds, nfds, 10, timeout);
     if(rc<0){
        printf("Error \n");
        exit(1);
     }

     else if(rc==0){
        printf("Waiting..\n");
        continue;
     }

        
     //oth ele i for the listener
       
    for (int i = 0; i < (nfds+1); i++)
        {
            if((fds + i) ->fd <=0)
            continue;

           
            
            if( (fds + i) ->fd ==sockfd)
                {
                    //new connection
                    clientSocket = accept(
			        sockfd, (struct sockaddr*)&cliAddr, &addr_size);

		            printf("Connection accepted from %s:%d\n",inet_ntoa(cliAddr.sin_addr),ntohs(cliAddr.sin_port));
		
                    if(fp == NULL) 
                   {
                      printf("file can't be opened\n");
                     exit(1);
                   }

	                fprintf( fp, "Connection accepted from %s:%d\n", inet_ntoa(cliAddr.sin_addr), ntohs(cliAddr.sin_port));
                    
                   
                    num++;
                    (fds+ num-1) -> fd = clientSocket;
                     (fds+ num-1) -> events = POLLIN;
                      (fds+ num-1) -> revents = 0;

                    
                }

                else
                {
                   func(fds[i].fd);
                   (fds+i) -> fd =-1;
                   
                }
        }
    }


    fclose(fp);
	
	return 0;

	}

   



   

