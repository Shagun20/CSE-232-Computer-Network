
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define MAX 80
#define PORT 8080
#define SA struct sockaddr
#define DATA_SIZE 1000
FILE * fp;
// Function designed for chat between client and server.
void func(int connfd)
{

    
	
 
	char buff[MAX];
	int n;
    long unsigned int fact=1;
	int time=0;

    


	for (;;) {


        int value;
        int recv;
		read(connfd,&value,sizeof(value));

		printf("Received client request number: %d\n ",value);
        fact=fact*value;

		fprintf( fp, "%lu\n ", fact);

		write(connfd, &fact, sizeof(unsigned long int));

		printf("Succesfully stored the results into the file !\n");
		
	
	}
}

// Driver function
int main()
{


	fp= fopen("file1.txt", "w");
	int sockfd, connfd, len;
	struct sockaddr_in servaddr, cli;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) {
		printf("socket creation failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully created..\n");
	bzero(&servaddr, sizeof(servaddr));

	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(PORT);

	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
		printf("socket bind failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully binded..\n");

	if ((listen(sockfd, 5)) != 0) {
		printf("Listen failed...\n");
		exit(0);
	}
	else
		printf("Server listening..\n");
	len = sizeof(cli);

	// Accept the data packet from client and verification
	connfd = accept(sockfd, (SA*)&cli, &len);
	if (connfd < 0) {
		printf("server accept failed...\n");
		exit(0);
	}
	

    // char data[DATA_SIZE]= "Connection accepted from";;
	// char str[DATA_SIZE];
	// sprintf(str, "%d", ntohs(cli.sin_port));

	// strcat(data,inet_ntoa(cli.sin_addr));
	// strcat(data, " ");
	// strcat(data, str);

    // printf(data);
    // fputs(data, fPtr);

	if(fp == NULL) {
        printf("file can't be opened\n");
        exit(1);
    }

	fprintf( fp, "Connection accepted from %s:%d\n",inet_ntoa(cli.sin_addr), ntohs(cli.sin_port));



	func(connfd);

	fclose(fp);

	
	close(sockfd);
}


 