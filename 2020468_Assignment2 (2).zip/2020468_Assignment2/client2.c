// C program for the Client Side
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#include <pthread.h>
#include <semaphore.h>

#define PORT 8080
#define SA struct sockaddr



void* clienthread(void* args)
{
    printf(" New client created\n");
	 int sockfd, connfd;
    struct sockaddr_in servaddr, cli;
 
    // socket create and verification
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("socket creation failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully created..\n");
    bzero(&servaddr, sizeof(servaddr));
 
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);
 
    
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr))
        != 0) {
        printf("connection with the server failed...\n");
        exit(0);
    }
    else
        printf("connected to the server..\n");



    int value;
    int n;
    unsigned long int recv;
    for (int i=1;i<=20;i++)
     {

        value=i;
        write(sockfd, &value, sizeof(int));
        read(sockfd, &recv, sizeof(unsigned long int));
        printf("Response received from Server : %lu\n ", recv);
    }
 
    // function for chat
   // func(sockfd);
         pthread_exit(NULL);
    // close the socket
}

// Driver Code
int main()
{

	

	 for(int i=0;i<10;i++){

       pthread_t tid;
		
	
		pthread_create(&tid, NULL,
					clienthread,
					(void *)&tid);

	pthread_join(tid, NULL);
    
   
	}

	
    return 0;



	

}
