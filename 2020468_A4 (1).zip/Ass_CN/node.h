#include <iostream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>

using namespace std;

class Node;
/*
  Each row in the table will have these fields
  dstip:	Destination IP address
  nexthop: 	Next hop on the path to reach dstip
  ip_interface: nexthop is reachable via this interface (a node can have multiple interfaces)
  cost: 	cost of reaching dstip (number of hops)
*/
class RoutingEntry{
 public:
  string dstip, nexthop, prevhop;
  Node* prevnode;
  //add another prevhop entry
  string ip_interface;
  int cost;
};

/*
 * Class for specifying the sort order of Routing Table Entries
 * while printing the routing tables
 * 
*/
//compares 2 routing table entries
class Comparator{
 public:
  bool operator()(const RoutingEntry &R1,const RoutingEntry &R2){
    if (R1.cost == R2.cost) {
      return R1.dstip.compare(R2.dstip)<0;
    }
    else if(R1.cost > R2.cost) {
      return false;
    }
    else {
      return true;
    }
  }
} ;

/*
  This is the routing table
*/
struct routingtbl {
  vector<RoutingEntry> tbl;
  //routing tbl is a vector of all the different routing entires
};

/*
  Message format to be sent by a sender
  from: 		Sender's ip
  mytbl: 		Senders routing table
  recvip:		Receiver's ip
*/
class RouteMsg {
 public:
  Node* node;
  //another var to detect which node the message is coming from 

  string from;			// I am sending this message, so it must be me i.e. if A is sending mesg to B then it is A's ip address
  struct routingtbl *mytbl;	// This is routing table of A
  string recvip;		// B ip address that will receive this message
};

/*
  Emulation of network interface. Since we do not have a wire class, 
  we are showing the connection by the pair of IP's
  
  ip: 		Own ip
  connectedTo: 	An address to which above mentioned ip is connected via ethernet.
*/
class NetInterface {
 private:
  string ip;
  string connectedTo; 	//this node is connected to this ip
  
 public:
  string getip() {
    return this->ip;
  }
  string getConnectedIp() {
    return this->connectedTo;
  }
  void setip(string ip) {
    this->ip = ip;
  }
  void setConnectedip(string ip) {
    this->connectedTo = ip;
  }
  
};

/*
  Struct of each node
  name: 	It is just a label for a node
  interfaces: 	List of network interfaces a node have
  Node* is part of each interface, it easily allows to send message to another node
  mytbl: 		Node's routing table
*/
class Node {
 private:
  string name;

 
  //ip addr and previous

  //adding a map to store all the routing tables for all the other nodes in the network

  unordered_set<Node*> visited;

  
  virtual void recvMsg(RouteMsg* msg) {
    cout<<"Base"<<endl;
  }


  
 public:
 struct routingtbl mytbl;

 bool isMyInterface(string eth) {
    for (int i = 0; i < interfaces.size(); ++i) {
      if(interfaces[i].first.getip() == eth)
	return true;
    }
    return false;
  }
   
  vector<pair<NetInterface, Node*> > interfaces;
  //interfaces is a vector of a pair containing interface to the node 

  unordered_map<Node*, struct routingtbl> recvd_tables;

   //adding a new data structure dijkstra set for each node 
  unordered_set<string> dijksta_set_for_this_node;

//new function added
  int get_dijkstra_set_size()
  {
    return dijksta_set_for_this_node.size();
  }


  void setName(string name){
    this->name = name;
  }
  
  void addInterface(string ip, string connip, Node *nextHop) {
    NetInterface eth;
    eth.setip(ip);
    eth.setConnectedip(connip);
    interfaces.push_back({eth, nextHop});
  }
  
  void addTblEntry(string myip, int cost) {

    for(int i=0;i<mytbl.tbl.size();i++){
      if(mytbl.tbl[i].dstip==myip && cost!=0){
        updateTblEntry(myip, cost);
      }
    }
    //create a new row called entry
    RoutingEntry entry;
    //update the parameters of this entry
    entry.dstip = myip;
    entry.nexthop = myip;
    entry.ip_interface = myip;
    entry.cost = cost;
    mytbl.tbl.push_back(entry);
  }

  void initialise(string dst,string curr, int c, string prev, Node* prev_node) {

      //only self entries are there
      //add all the entries as are the 
      RoutingEntry newEntry;
      newEntry.dstip = dst;
      
      newEntry.ip_interface = curr;
      newEntry.cost = c;

      newEntry.prevhop = prev;
      newEntry.prevnode = prev_node;



      mytbl.tbl.push_back(newEntry);
    //create a new row called entry
   
   
  }


  void updateTblEntry(string dstip, int cost) {
    // to update the dstip hop count in the routing table (if dstip already exists)
    // new hop count will be equal to the cost 
    for (int i=0; i<mytbl.tbl.size(); i++){
      RoutingEntry entry = mytbl.tbl[i];

      if (entry.dstip == dstip) 
        mytbl.tbl[i].cost = cost;

    }

    // remove interfaces 
    for(int i=0; i<interfaces.size(); ++i){
      // if the interface ip is matching with dstip then remove
      // the interface from the list
      if (interfaces[i].first.getConnectedIp() == dstip) {
        interfaces.erase(interfaces.begin() + i);
      }
    }
  }
  
  string getName() {
    return this->name;
  }
  
  struct routingtbl getTable() {
    return mytbl;
  }
  
  void printTable() {
    Comparator myobject;
    sort(mytbl.tbl.begin(),mytbl.tbl.end(),myobject);
    cout<<this->getName()<<":"<<endl;
    for (int i = 0; i < mytbl.tbl.size(); ++i) {
      cout<<mytbl.tbl[i].dstip<<" | "<<mytbl.tbl[i].nexthop<<" | "<<mytbl.tbl[i].ip_interface<<" | "<<mytbl.tbl[i].cost <<endl;
    }
  }

  void receive_the_message(RouteMsg *msg) 
  {
 
    
    struct routingtbl *recvRoutingTable = msg->mytbl;

    //recvRotingtbl is a pointer to the recived table

    //we create a new copy of this table and store 

    struct routingtbl new_table;

    new_table.tbl= (*recvRoutingTable).tbl;
    
    Node* src_node= msg->node;

    
    recvd_tables.insert({src_node, new_table});

    cout<<"\n Table received from"<<src_node->name<<" at node "<<name;

    //obtain the node out of the 
    
    //store the received tables, and choose as per the node from which it has come out



   }
  
  //this function will allow the interfaces to retransmit the msg in the same way to all the nodes
  void send(RouteMsg msg, Node *n )
  {
    
    for (int i = 0; i < n->interfaces.size(); ++i)
    {
    
    msg.recvip = n->interfaces[i].first.getConnectedIp();	
    //send the messages to these people first
     
    Node* node = n->interfaces[i].second;

    if(visited.find(node)!= visited.end())
    {
        //the particular node has already received the routing table, continue to the next iteration
        continue;
    }


    //the next node will receive the message as soon as the table has been transmitted
    node->receive_the_message(&msg);
    
    //as soon as "node" receives curr nodes tables, mark it into visited
    visited.insert(n);

    send(msg, node);

    } 
    
  
  }
 
  void sendMsg()
  {
    struct routingtbl ntbl;
    //storing a copy of node's current routing table into ntbl
    for (int i = 0; i < mytbl.tbl.size(); ++i) {
      ntbl.tbl.push_back(mytbl.tbl[i]);
    }
     
    //for all the neighbours connected to the current node 
    for (int i = 0; i < interfaces.size(); ++i)
    {
    //create a message sending out from the node A containing the copy of the 
    //current routing tbl of the node

    RouteMsg msg;
    msg.node = this;

    //attach name of the node message is being sent from 
    msg.from = interfaces[i].first.getip();
    msg.mytbl = &ntbl;
    msg.recvip = interfaces[i].first.getConnectedIp();	
    //send the messages to these people first
     
    Node* node = interfaces[i].second;

    //the next node will receive the message as soon as the table has been transmitted
    node->receive_the_message(&msg);
    
    visited.insert(node);
    //dfs send to all the nodes
    send(msg, node);

    } 

    cout<<"\n Message sent from node: of table of size "<< name<< mytbl.tbl.size()<<"\n\n";
  }
  
};

class RoutingNode: public Node {
 public:
  void recvMsg();
};
