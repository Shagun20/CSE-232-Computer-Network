#include "node.h"
#include <iostream>

using namespace std;


void printRT(vector<RoutingNode*> nd){
  cout<<1;
/*Print routing table entries*/
	for (int i = 0; i < nd.size(); i++) {
	  nd[i]->printTable();
	}
}

//new function for checking convergence added
bool has_converged(vector<RoutingNode*> nd)
{
  
  int n=nd.size();
  //n is the number of nodes
  

  //for all the nodes, just check if their dijkstra has been converged
  
  for(int i=0;i<n;i++){
   
   if(nd[i]->get_dijkstra_set_size() ==n){
    continue;
   }

   else{
    return false;
   }

  }

  return true;

}


void routingAlgo(vector<RoutingNode*> nd)
{
 
  bool saturation=false;
  
    for (RoutingNode* node: nd)
    {
     node->sendMsg();
      //each node will send its message to all the nodes in the netw
    }
  

  //after the sending of this info has happened

 
    for (RoutingNode* node: nd)
    {
     node->recvMsg();
      //each node will send its message to all the nodes in the netw
    }
  
   

  //keep checking if convergence has occured in this loop
  // while(!saturation){

  //   saturation=has_converged(nd);
  //   cout<<1;

  // }
  /*Print routing table entries after routing algo converges */
  printf("Printing the routing tables after the convergence \n");
   printRT(nd);

}


bool check_key(string key, unordered_set<string> dijksta )
{
    // Key is not present
    if (dijksta.count(key) == 0)
        return false;
 
    return true;
}


void RoutingNode::recvMsg() {
 
  
  //assuming an initial table has already been created for the node
  
    
  //add ip addr of the destinations of its own self inside the table
  for(int i=0;i<interfaces.size();i++){
      dijksta_set_for_this_node.insert(interfaces[i].first.getip());
  }

  //we will loop in the entries of the table
  
  //keep doing this till convergence
  while(dijksta_set_for_this_node.size()!=mytbl.tbl.size() )
  {

  //find the smallest distance destinations from A , ignore already present in dijkstra set

  int min= INT_LEAST32_MAX;
  //store the min entry as is

  //cost of the interfaces having the same nodes is considered all at same time

  // //create a vector for min entry
  vector<struct RoutingEntry> min_entries;
  struct RoutingEntry minentry;
  for(int i=0;i<mytbl.tbl.size(); i++)
  {
   
   struct RoutingEntry entry= mytbl.tbl[i];
   
   //check if set has contained the dest addresses already

   if(check_key(entry.dstip,dijksta_set_for_this_node))
   {
     continue;
   }
   
   //find the min cost; 
   if(entry.cost<min)
   {
    min=entry.cost;
    minentry= entry;
    min_entries.push_back(minentry);
   }



  }

  //find node to which my dest ip address is connected 
  //group them all
  //traverse the keys of recvd tables
  //and check if the current interface is connected to which node
  Node* found_node;
   for (auto i = recvd_tables.begin(); i != recvd_tables.end(); i++)
   {
         Node* n= i->first;
         //ip of the interface
         if(n->isMyInterface(minentry.dstip)){
          //
          found_node=n;
          break;
         }
   }



  //group all the interfaces connected to the just found node
  //add them into the table at same time
  
  for(int i=0;i<min_entries.size();i++)
  {
        if(found_node->isMyInterface(min_entries[i].dstip))
        {
               dijksta_set_for_this_node.insert(min_entries[i].dstip );

        }
  }

  //add this entry's dst ip to dijkstra
  
  routingtbl found_node_table = recvd_tables[found_node];
  //now update all the entries of table A, based on the min newly received node found_node
  
  unordered_map<string, int> neighbours;
  //the received tables have some neighbours,
  //the original cost to reach now will be min of current cost and the cost to reach from the found node


  //store the mapping of the neighbours of found_node
  //after adding min cost to the neighbours

  for(int i=0;i<mytbl.tbl.size(); i++){

    //update only entries of neighbours 
    struct RoutingEntry entry= mytbl.tbl[i];

    //check if set has contained the dest addresses already
   if(check_key(entry.dstip,  dijksta_set_for_this_node ))
   {
     continue;
   }

    //find entry from the tbl of found_node_table
    for(int j=0;j<found_node_table.tbl.size();j++)
    {

      if(found_node_table.tbl[j].dstip==entry.dstip)
      {
        //consider only the neighbours 
        if(found_node_table.tbl[j].cost!= INT32_MAX)
        {
             if(entry.cost < min+found_node_table.tbl[j].cost)
             {
              entry.cost= min + found_node_table.tbl[j].cost;


              entry.prevhop= found_node_table.tbl[j].ip_interface;

              entry.prevnode= found_node;

              //store the interface id of the found node

             }
             

        }
        
      }
    }

  }


  //access the routing table of the corresponding node or ip interface 
  
  //store the costs in a hshmap 


}

}





